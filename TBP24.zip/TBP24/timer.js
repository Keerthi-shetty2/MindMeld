// timer.js

// Countdown timer for 5 minutes (300 seconds)
let timeLeft = 300;

// Function to update the countdown timer
function updateTimer() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;

    const countdown = document.getElementById("countdown");
    countdown.textContent = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;

    if (timeLeft > 0) {
        timeLeft--;
        setTimeout(updateTimer, 1000); // Update every 1 second (1000 milliseconds)
    } else {
        countdown.textContent = "Exercise completed!";
    }
}

// Initialize the timer
updateTimer();
